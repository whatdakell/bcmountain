<?php
/**
 * Theme functions and definitions
 *
 * @package HelloElementorChild
 */

/**
 * Load child theme css and optional scripts
 *
 * 
 */

// function hello_elementor_child_enqueue_scripts() {
// 	wp_enqueue_style(
// 		'hello-elementor-child-style',
// 		get_stylesheet_directory_uri() . '/style.css',
// 		[
// 			'hello-elementor-theme-style',
// 		],
// 		'1.0.0'
// 	);
// }
// add_action( 'wp_enqueue_scripts', 'hello_elementor_child_enqueue_scripts', 20 );

// function set_custom_ver_css_js( $src ) {
// 	// style.css URI
// 	$style_file = get_stylesheet_directory().'/style.css'; 

// 	if ( $style_file ) {
// 		// css file timestamp
// 		$version = filemtime($style_file); 
		
// 		if ( strpos( $src, 'ver=' ) )
// 			// use the WP function add_query_arg() 
// 			// to set the ver parameter in 
// 			$src = add_query_arg( 'ver', $version, $src );
// 		return esc_url( $src );

// 	}

// }

function hello_elementor_child_enqueue_scripts() {
	wp_enqueue_style( 'wpb-google-fonts', 'https://fonts.googleapis.com/css2?family=Lexend+Exa:wght@100;200;300;400;700;800&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap', false );
	wp_enqueue_style(
		'hello-elementor-child-style', get_stylesheet_directory_uri() . '/style.css', false,'1.2'
	);
}
function unhook_parent_style() {

    wp_dequeue_style( 'hello-elementor-theme-style' );
    wp_deregister_style( 'hello-elementor-theme-style' );
    wp_dequeue_style( 'hello-elementor' );
    wp_deregister_style( 'hello-elementor' );
    
    // hello-elementor
  }
  add_action( 'wp_enqueue_scripts', 'unhook_parent_style', 20 );

// function disable_styles() {
// 	wp_dequeue_style('elementor-frontend-lite');
// 	wp_deregister_style('elementor-frontend-lite');
// 	// wp_dequeue_style('widget-nav-menu');
// 	// wp_deregister_style('widget-nav-menu');	
// 	// wp_dequeue_style('hello-elementor-theme-style');
// 	// wp_deregister_style('hello-elementor-theme-style');

// }

// add_action('wp_enqueue_scripts', 'disable_styles', 100);

add_action( 'wp_enqueue_scripts', 'hello_elementor_child_enqueue_scripts', 103);

function scripts_and_styles()
{
    wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js');
    wp_enqueue_script('jquery');
    wp_register_script('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js');
    wp_enqueue_script('owl-carousel');
		wp_enqueue_style( 'animate-css', 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css' );
		wp_enqueue_style( 'style', get_stylesheet_uri() );
		
    wp_register_script('e-custom', get_stylesheet_directory_uri() . '/e-custom.js', false,'1.2');
    wp_enqueue_script('e-custom');
}

add_action('wp_enqueue_scripts', 'scripts_and_styles');


add_filter('use_block_editor_for_post_type', 'prefix_disable_gutenberg', 10, 2);
function prefix_disable_gutenberg($current_status, $post_type)
{
    // Use your post type key instead of 'product'
    if ($post_type === 'winners') return false;
    return $current_status;
}
add_filter('use_block_editor_for_post_type', '__return_false');



add_filter( 'hello_elementor_page_title', '__return_false' );


